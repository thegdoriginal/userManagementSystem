const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const session = require('express-session');
const Store = require('connect-mongodb-session')(session);

const router = require('./routes/router');
// require('./db/conn');

const app = express();
const MONGO_URI = 'mongodb+srv://darshan:p%40ssword@cluster0.uptvokt.mongodb.net/?retryWrites=true&w=majority'
const store = new Store({
    uri: MONGO_URI,
    collection: 'sessions'
});

app.set('view engine', 'ejs');
app.set('view', 'view');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({
    secret: 'secret',
    saveUninitialized: false,
    resave: false,
    store: store
}));
app.use(router);

mongoose.set('strictQuery', true);
mongoose.connect(MONGO_URI)
    .then(result => {
        app.listen(4444);
    })
    .catch(err => console.log(err));